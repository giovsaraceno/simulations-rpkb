<h1 align="center">

Rnanoflann

</h1>

### **Version 0.0.3**

------------------------------------------------------------------------

> **New**
>
> | Function | What's new!                              |
> |----------|------------------------------------------|
> | nn       | fix bug about using abs function for numeric to integer. |


### **Version 0.0.2**

------------------------------------------------------------------------

> **New**
>
> | Function | What's new!                              |
> |----------|------------------------------------------|
> | nn       | add new metrics with parallel version, "hellinger","canberra","kullback_leibler","jensen_shannon","itakura_saito","bhattacharyya","jeffries_matusita","minimum","maximum","total_variation","sorensen,"cosine","gower","minkowski","soergel","kulczynski","wave_hedges","motyka","harmonic_mean". |
> | nn       | fix bug in metric "euclidean". |
>
> **LinkingTo**
>
> | Function | What's new!                              |
> |----------|------------------------------------------|
> | nn       | add new metrics with parallel version, "hellinger","canberra","kullback_leibler","jensen_shannon","itakura_saito","bhattacharyya","jeffries_matusita","minimum","maximum","total_variation","sorensen,"cosine","gower","minkowski","soergel","kulczynski","wave_hedges","motyka","harmonic_mean". |
> | nn       | fix bug in metric "euclidean". |


### **Version 0.0.1**

------------------------------------------------------------------------

> **New**
>
> | Function | What's new!                              |
> |----------|------------------------------------------|
> | nn       | Nearest neighboors with parallel version |
>
> **LinkingTo**
>
> | Function | What's new!                              |
> |----------|------------------------------------------|
> | nn       | Nearest neighboors with parallel version |
