colspml.mle <- function(x, tol = 1e-07, maxiters = 100, parallel = FALSE) {
  Rfast2::colspml.mle(x = x, tol = tol, maxiters = maxiters, parallel = parallel)
}
