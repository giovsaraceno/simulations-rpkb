################################
#### Random values generation from the angular central Gaussian distribution
#### Tsagris Michail 03/2016
#### mtsagris@yahoo.gr
################################
racg <- function(n, sigma) {
  Rfast::racg(n, sigma)
}
