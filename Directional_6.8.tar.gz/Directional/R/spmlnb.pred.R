spmlnb.pred <- function(xnew, mu1, mu2, ni) {
  Rfast2::spmlnb.pred(xnew, mu1, mu2, ni)
}
