vmnb.pred <- function(xnew, mu, kappa, ni) {
  Rfast2::vmnb.pred(xnew, mu, kappa, ni)
}
