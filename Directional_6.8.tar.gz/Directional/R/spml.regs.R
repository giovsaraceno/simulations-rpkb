spml.regs <- function(y, x, tol = 1e-07, logged = FALSE, maxiters = 100, parallel = FALSE) {
  Rfast::spml.regs(y = y, x = x, tol = tol, logged = logged, maxiters = maxiters, parallel = parallel)
}
