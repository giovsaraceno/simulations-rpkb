spml.nb <- function(xnew = NULL, x, ina, tol = 1e-07) {
  Rfast2::spml.nb(xnew = xnew, x = x, ina = ina, tol = tol)
}
