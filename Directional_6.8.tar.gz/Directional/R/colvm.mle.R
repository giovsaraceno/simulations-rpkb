colvm.mle <- function(x, tol = 1e-07) {
  Rfast::colvm.mle(x = x, tol = tol)
}
