read.fbm <- function(file, select) {
  bigstatsr::big_read(file = file, select = select)
}
