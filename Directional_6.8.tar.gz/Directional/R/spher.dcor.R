spher.dcor <- function(x, y) {
  Rfast::dcor(x, y) 
}