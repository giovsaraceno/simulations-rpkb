vm.nb <- function(xnew = NULL, x, ina, tol = 1e-07) {
  Rfast2::vm.nb(xnew, x, ina, tol)
}



